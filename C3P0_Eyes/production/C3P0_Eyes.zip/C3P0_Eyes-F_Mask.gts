G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.2-1*
G04 #@! TF.CreationDate,2025-02-14T16:50:31-05:00*
G04 #@! TF.ProjectId,C3P0_Eyes,43335030-5f45-4796-9573-2e6b69636164,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.2-1) date 2025-02-14 16:50:31*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMHorizOval*
0 Thick line with rounded ends*
0 $1 width*
0 $2 $3 position (X,Y) of the first rounded end (center of the circle)*
0 $4 $5 position (X,Y) of the second rounded end (center of the circle)*
0 Add line between two ends*
20,1,$1,$2,$3,$4,$5,0*
0 Add two circle primitives to create the rounded ends*
1,1,$1,$2,$3*
1,1,$1,$4,$5*%
%AMRotRect*
0 Rectangle, with rotation*
0 The origin of the aperture is its center*
0 $1 length*
0 $2 width*
0 $3 Rotation angle, in degrees counterclockwise*
0 Add horizontal line*
21,1,$1,$2,0,0,$3*%
G04 Aperture macros list end*
%ADD10C,3.200000*%
%ADD11RotRect,1.700000X1.700000X315.000000*%
%ADD12HorizOval,1.700000X0.000000X0.000000X0.000000X0.000000X0*%
%ADD13RotRect,1.700000X1.700000X45.000000*%
%ADD14HorizOval,1.700000X0.000000X0.000000X0.000000X0.000000X0*%
%ADD15R,1.500000X1.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X121000000Y-100000000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X79000000Y-100000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J2*
X86523000Y-91487000D03*
D12*
X88319051Y-89690949D03*
X90115102Y-87894898D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J1*
X113877000Y-91741000D03*
D14*
X112080949Y-89944949D03*
X110284898Y-88148898D03*
G04 #@! TD*
D15*
G04 #@! TO.C,D3*
X107977000Y-107620000D03*
X107977000Y-104420000D03*
X112877000Y-104420000D03*
X112877000Y-107620000D03*
G04 #@! TD*
G04 #@! TO.C,D2*
X87123000Y-107620000D03*
X87123000Y-104420000D03*
X92023000Y-104420000D03*
X92023000Y-107620000D03*
G04 #@! TD*
G04 #@! TO.C,D1*
X97550000Y-86359000D03*
X97550000Y-89559000D03*
X102450000Y-89559000D03*
X102450000Y-86359000D03*
G04 #@! TD*
M02*
